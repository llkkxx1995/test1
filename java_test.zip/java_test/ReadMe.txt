1.编译 mvn clean compile
2.执行 mvn exec:java -Dexec.mainClass="com.hand.Try" -Dexec.args="arg0 arg1 arg2"
